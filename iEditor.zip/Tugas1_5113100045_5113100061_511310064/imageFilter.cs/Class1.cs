﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;

namespace imageFilter.cs
{
    public class Class1
    {
        private void black_white(Bitmap bmp)
        {

        }
    }
}
