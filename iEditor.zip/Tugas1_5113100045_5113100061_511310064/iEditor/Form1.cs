﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Emgu.CV;
using Emgu.CV.UI;
using Emgu.Util;
using Emgu.CV.Structure;
using AForge.Imaging.Filters;
//using AForge.Imaging;
using AForge.Controls;

namespace iEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool thereIsImage = false;
        int width;
        int height;
        int brightness = 0;
        Image<Bgr, byte> imgH;
       // Mat mat = new Mat();
        String imageName;
        Bitmap bmp;
        Image original;
        Image gambarAsli;
        //Image saveImage;
        Color p;
        IFilter grayScaleFilter = new Grayscale(0.21, 0.72, 0.03);
        HistogramEqualization he = new HistogramEqualization();
        Sharpen filter = new Sharpen();
        Sepia sepiaFilter = new Sepia();
        Median medianFilter = new Median();

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        public Bitmap histogramEqualization(Bitmap sourceImage)
        {
            Bitmap newImage = sourceImage;

            uint pixels = (uint)newImage.Height * (uint)newImage.Width;
            decimal Const = 255 / (decimal)pixels;

            int x, y, R, G, B;

            AForge.Imaging.ImageStatistics statistics = new AForge.Imaging.ImageStatistics(newImage);

            int[] cdfR = statistics.Red.Values.ToArray();
            int[] cdfG = statistics.Green.Values.ToArray();
            int[] cdfB = statistics.Blue.Values.ToArray();

            for (int r = 1; r <= 255; r++)
            {
                cdfR[r] = cdfR[r] + cdfR[r - 1];
                cdfG[r] = cdfG[r] + cdfG[r - 1];
                cdfB[r] = cdfB[r] + cdfB[r - 1];

            }

            for (y = 0; y < newImage.Height; y++)
            {
                for (x = 0; x < newImage.Width; x++)
                {
                    Color pixelColor = newImage.GetPixel(x, y);

                    R = (int)((decimal)cdfR[pixelColor.R] * Const);
                    G = (int)((decimal)cdfG[pixelColor.G] * Const);
                    B = (int)((decimal)cdfB[pixelColor.B] * Const);

                    Color newColor = Color.FromArgb(R, G, B);
                    newImage.SetPixel(x, y, newColor); 
                }
            }

            return newImage;
        }

        private Bitmap laplacian(Bitmap bm)
        {
            Bitmap bm1 = new Bitmap(bm.Width, bm.Height);
            int width = bm.Width - 1;
            int height = bm.Height - 1;

            for (int i = 1; i < width; i++)
            {
                for (int j = 1; j < height; j++)
                {
                    Color color2, color4, color5, color6, color8;

                    color2 = bm.GetPixel(i, j - 1);
                    color4 = bm.GetPixel(i - 1, j);
                    color5 = bm.GetPixel(i, j);
                    color6 = bm.GetPixel(i + 1, j);
                    color8 = bm.GetPixel(i, j + 1);

                    int colorRed = color2.R + color4.R + color5.R * (-4) + color6.R + color8.R;
                    int colorGreen = color2.G + color4.G + color5.G * (-4) + color6.G + color8.G;
                    int colorBlue = color2.B + color4.B + color5.B * (-4) + color6.B + color8.B;

                    int avg = ((colorRed + colorGreen + colorBlue) / 3);

                    if (avg > 255)
                        avg = 255;
                    if (avg < 0)
                        avg = 0;
                    bm1.SetPixel(i, j, Color.FromArgb(avg, avg, avg));
                }
            }

            return bm1;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                imageName = openFile.FileName;              
                Image imgOri = Image.FromFile(openFile.FileName);
                gambarAsli = imgOri;
                this.original = imgOri;
                Image copyImage = imgOri;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox1.Image = imgOri;
                labelImageLocation.Text = imageName;
               
                //CvInvoke.BitwiseNot(img, mat);

                bmp = (Bitmap)copyImage;
                this.width = bmp.Width;
                this.height = bmp.Height;
                string sizeImage = this.width.ToString() + "x" + this.height.ToString();
                labelSize.Text = sizeImage;

                this.thereIsImage = true;
                
                /*Mat imgOriginal = CvInvoke.Imread("Image1", Emgu.CV.CvEnum.LoadImageType.AnyColor);
                imgH = imgOriginal.ToImage<Bgr, Byte>();
                histogramBox1_Load(sender, e);*/
                

            }
        }

        private int black_white(Color p, int x, int y)
        {
            //lama 20 sec. --> method average
            //int a = p.A;
            int r = p.R;
            int g = p.G;
            int b = p.B;

            //int avg = (r + g + b) / 3;

            //luminosity
            double lumi = 0.21 * r + 0.72 * g + 0.07 * b;
            int grayV = (int)lumi;

            // bmp.SetPixel(x,y,Color.FromArgb(a,grayV,grayV,grayV));


            //one channel
            //bmp.SetPixel(x, y, Color.FromArgb(a, r, r, r));

            //average
            //bmp.SetPixel(x, y, Color.FromArgb(a, avg, avg, avg));

            return grayV;
        }

        private void bOldFilm_Click(object sender, EventArgs e)
        {
            if (thereIsImage)
            {
                for (int y = 0; y < this.height; y++)
                 {
                     for (int x = 0; x < this.width; x++)
                     {
                          p = bmp.GetPixel(x, y);
                          int a = p.A;
                          int grayV = this.black_white(p, x, y);
                          bmp.SetPixel(x,y,Color.FromArgb(a,grayV,grayV,grayV));
                     }
                 }

                Image imgOld = (Image)bmp;
                pictureBox1.Image = imgOld;

                //this.bmp = grayScaleFilter.Apply(bmp);
                //pictureBox1.Image = bmp;
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            DialogResult dr = saveDialog.ShowDialog();
            Image saveFileImage = (Image) this.bmp;
            Bitmap saveImageBMP = this.bmp;

            if (dr == DialogResult.OK)
            {
                if (thereIsImage)
                {
                    if (saveDialog.FileName.Substring(saveDialog.FileName.Length - 3).ToLower() == "jpg")
                    {
                        saveFileImage.Save(saveDialog.FileName, ImageFormat.Jpeg);
                    }

                    if (saveDialog.FileName.Substring(saveDialog.FileName.Length - 3).ToLower() == "bmp")
                    {
                        saveImageBMP.Save(saveDialog.FileName, ImageFormat.Bmp);
                    }
                }
            }
            //pictureBox1.Image.Save("baboon.jpg");
        }

        private void bNegative_Click(object sender, EventArgs e)
        {
            if (thereIsImage)
            {
                for (int y = 0; y < this.height; y++)
                {
                    for (int x = 0; x < this.width; x++)
                    {
                        p = bmp.GetPixel(x, y);

                        int a = p.A;
                        int r = 255-p.R;
                        int g = 255-p.G;
                        int b = 255-p.B;

                        bmp.SetPixel(x, y, Color.FromArgb(a, r, g, b));
                    }
                }

                pictureBox1.Image = bmp;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (thereIsImage)
            {
                /*for (int y = 0; y < this.height; y++)
                {
                    for (int x = 0; x < this.width; x++)
                    {
                        p = bmp.GetPixel(x, y);

                        int a = p.A;
                        int r = p.R+10;
                        int g = p.G+10;
                        int b = p.B+10;

                        //double tr = 0.393*r + 

                        bmp.SetPixel(x, y, Color.FromArgb(a, r, g, b));
                    }
                }*/
                this.bmp = sepiaFilter.Apply(bmp);

                pictureBox1.Image = bmp;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (thereIsImage)
            {
                //this.bmp = he.Apply(bmp);
                Bitmap heImage = histogramEqualization(bmp);
                //this.bmp = filter.Apply(bmp);
                pictureBox1.Image = heImage;

                //Image h = (Image)bmp;
                
                
               // histogramBox1.Show();
            }
        }

        private void bOriginal_Click(object sender, MouseEventArgs e)
        {
            pictureBox1.Image = gambarAsli;
            this.bmp = (Bitmap)gambarAsli;
           // Image originalImage = this.original;
           // pictureBox1.Image = this.original;
            
            //pictureBox1.Image = bmp;
        }

        private Bitmap aturBrightness(Bitmap Image, int value)
        {
            Bitmap tempBitmap = Image;
            float finalValue = (float)value / 255.0f;
            Bitmap newBitmap = new Bitmap(tempBitmap.Width, tempBitmap.Height);
            Graphics newGraphics = Graphics.FromImage(newBitmap);

            float[][] floatColorMatrix = {
                new float[] {1,0,0,0,0},
                new float[] {0,1,0,0,0},
                new float[] {0,0,1,0,0},
                new float[] {0,0,0,1,0},
                new float[] {finalValue, finalValue, finalValue, 1, 1}
                                         };
            ColorMatrix newColorMatrix = new ColorMatrix(floatColorMatrix);
            ImageAttributes attributes = new ImageAttributes();

            attributes.SetColorMatrix(newColorMatrix);
            newGraphics.DrawImage(tempBitmap, new Rectangle(0, 0, tempBitmap.Width, tempBitmap.Height), 0, 0, tempBitmap.Width, tempBitmap.Height, GraphicsUnit.Pixel, attributes);
            attributes.Dispose();
            newGraphics.Dispose();

            return newBitmap;

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label2.Text = trackBar1.Value.ToString();
            pictureBox1.Image = aturBrightness(this.bmp, trackBar1.Value);
        }

        private void histogramBox1_Load(object sender, EventArgs e)
        {
            
            histogramBox1.GenerateHistograms(imgH, 256);
            HistogramViewer.Show(imgH);
            histogramBox1.Enabled = true;
            //histogramBox1.GenerateHistograms(imgH, 256);
            
            histogramBox1.Refresh();
            //histogramBox1.AddHistogram();
           // histogramBox1.Show();
        }

        private void bOriginal_Click(object sender, EventArgs e)
        {
            this.bmp = (Bitmap)this.original;
            pictureBox1.Image = this.bmp;
        }

        private void bLaplacian_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = laplacian(this.bmp);
        }

        private void bMedian_Click(object sender, EventArgs e)
        {
            this.bmp =  medianFilter.Apply(bmp);
            pictureBox1.Image = this.bmp;
        }

        
    }
}
